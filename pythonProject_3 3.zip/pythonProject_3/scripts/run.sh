python main.py --function 2
