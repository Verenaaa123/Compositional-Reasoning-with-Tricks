import sympy as sp
from sympy import factor
import random
from sympy import Poly
import re
from thefuzz import fuzz 
import sys
sys.path.append('..')
from config import all_tricks


class FormulaManipulator:
    def __init__(self):
        self.variable_library = list('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz') + \
                               [chr(i) for i in range(0x03B1, 0x03C9 + 1)]
        self.operations_list = [1, 2, 3, 4, 5, 6, 7, 8]
        self.local_dict = {
            # 三角函数
            'sin': sp.Function('sin'),
            'cos': sp.Function('cos'),
            'tan': sp.Function('tan'),
            'cot': sp.Function('cot'),
            
            # 常用符号
            'pi': sp.Symbol('pi'),
            'alpha': sp.Symbol('alpha'),
            'beta': sp.Symbol('beta'),
            
            # 基础变量
            'a': sp.Symbol('a'),
            'b': sp.Symbol('b'),
            'n': sp.Symbol('n'),
            'k': sp.Symbol('k'),
            
            # 数列相关
            'S_n': sp.Symbol('S_n'),
            'a_1': sp.Symbol('a_1'),
            'q': sp.Symbol('q'),
            'd': sp.Symbol('d'),
            'Q': sp.Symbol('Q'),
            'W': sp.Symbol('W'),
            'E': sp.Symbol('E'),
            'R': sp.Symbol('R'),
            'T': sp.Symbol('T'),
            'Y': sp.Symbol('Y'),
            'U': sp.Symbol('U'),
            'I': sp.Symbol('I'),
            'O': sp.Symbol('O'),
            'P': sp.Symbol('P')
        }


    # 转sympy+返回变量名
    def parse_user_formula(self, formula_str):
        print(f"\n=== 开始解析公式 ===")
        print(f"输入公式: '{formula_str}'")
        
        if not isinstance(formula_str, str):
            formula_str = str(formula_str)

        formula_str = formula_str.replace('==', '=')
        formula_str = formula_str.replace('α', 'alpha')
        formula_str = formula_str.replace('β', 'beta')
        formula_str = formula_str.replace('π', 'pi')
    

        for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz':
            if c not in self.local_dict:
                self.local_dict[c] = sp.Symbol(c)
        greek_letters = ['delta', 'gamma', 'theta', 'lambda', 'mu', 'xi', 'sigma', 'tau', 'phi', 'omega', 'zeta']
        for letter in greek_letters:
            self.local_dict[letter] = sp.Symbol(letter)
        
        if '=' in formula_str:
            left_side, right_side = formula_str.split('=', 1)
            left_side = left_side.strip()
            right_side = right_side.strip()
            
            print(f"处理等式左边: '{left_side}'")
            print(f"处理等式右边: '{right_side}'")
            
            left_expr = sp.sympify(left_side, locals=self.local_dict)
            right_expr = sp.sympify(right_side, locals=self.local_dict)
            expr = sp.Eq(left_expr, right_expr)
        else:
            expr = sp.sympify(formula_str, locals=self.local_dict)
        
        variables = list(expr.free_symbols)
        return expr, variables



    def separate_left(self, formula):
        formula = str(formula)
        formula = formula.replace('==', '=')
        sides = re.split(r'=(?!=)', formula)
        
        for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz':
            if c not in self.local_dict:
                self.local_dict[c] = sp.Symbol(c)
        greek_letters = ['delta', 'gamma', 'theta', 'lambda', 'mu', 'xi', 'sigma', 'tau', 'phi', 'omega', 'zeta']

        for letter in greek_letters:
            self.local_dict[letter] = sp.Symbol(letter)
        
        if len(sides) == 2:
            return sp.sympify(sides[0].strip(), locals=self.local_dict)
        return sp.sympify(formula, locals=self.local_dict)



    def separate_right(self, formula):
        formula = str(formula)
        formula = formula.replace('==', '=')
        sides = re.split(r'=(?!=)', formula)
        
        for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz':
            if c not in self.local_dict:
                self.local_dict[c] = sp.Symbol(c)
        
        greek_letters = ['delta', 'gamma', 'theta', 'lambda', 'mu', 'xi', 'sigma', 'tau', 'phi', 'omega', 'zeta']
        for letter in greek_letters:
            self.local_dict[letter] = sp.Symbol(letter)
        
        if len(sides) == 2:
            return sp.sympify(sides[1].strip(), locals=self.local_dict)
        return sp.sympify(formula, locals=self.local_dict)
      


    def generate_new_formulas(expr, variables, num_samples):#变量换数字
        newFunctions = []
        for _ in range(num_samples):
            substitution = {var: random.randint(1, 20) for var in
                            random.sample(variables, random.randint(1, len(variables) - 1))}
            new_expr = expr.subs(substitution)
            newFunctions.append(str(new_expr))

        return newFunctions



    def multiply_with_num(self, formula):
        # 将输入转换为字符串并检查是否包含等号
        formula_str = str(formula)
        if '=' in formula_str:
            left, right = formula_str.split('=', 1)
            left = left.strip()
            right = right.strip()
            multiplier = random.randint(2, 5)
          
            def is_numeric(expr_str):
                try:
                    float(expr_str)
                    return True
                except ValueError:
                    return False
            
            if not is_numeric(left) and not is_numeric(right):
                left_expr = sp.sympify(left, locals=self.local_dict)
                right_expr = sp.sympify(right, locals=self.local_dict) 
                new_left = left_expr * multiplier
                new_right = right_expr * multiplier
                return f"{new_left} = {new_right}"
            return formula_str    
        else:
            if not any(c.isalpha() for c in formula_str):
                return formula_str
        


    def add_elements(self, expr):
        expr_str = str(expr)
        constant = random.randint(-5, 5)
        if constant == 0:
            constant = 1 
        if '=' in expr_str:
            left, right = expr_str.split('=', 1)
            left = left.strip()
            right = right.strip()
            
            def is_numeric(expr_str):
                try:
                    float(expr_str)
                    return True
                except ValueError:
                    return False
                
            if not is_numeric(left) and not is_numeric(right):
                left_expr = sp.sympify(left, locals=self.local_dict)
                right_expr = sp.sympify(right, locals=self.local_dict)
                if random.choice([True, False]):
                    left = left_expr + constant
                    right = right_expr + constant
                else:
                    left = left_expr - constant
                    right = right_expr - constant
                left_con = sum(term for term in left.as_ordered_terms() if term.is_number)
                left_var = sum(term for term in left.as_ordered_terms() if not term.is_number)
                combined_left = left_con + left_var
                right_con = sum(term for term in right.as_ordered_terms() if term.is_number)
                right_var = sum(term for term in right.as_ordered_terms() if not term.is_number)
                combined_right = right_con + right_var
                return f"{combined_left} = {combined_right}"           
            return expr_str
            
        else:
            if not any(c.isalpha() for c in expr_str):
                return f"{expr_str} = {expr_str}"

    def num_replace_with_num(self, formula):
        if not isinstance(formula, str):
            formula = str(formula)   

        if '=' in formula:
            left, right = formula.split('=', 1)
            left = left.strip()
            right = right.strip()
        else:
            left = formula
            right = ""
        # 在左右两边查找数字
        numbers = re.findall(r'\d+', left) + re.findall(r'\d+', right)
        if not numbers:
            return formula
        
        number_pool = list(range(1, 101))
        replacement_count = random.randint(1, len(numbers))
        numbers_to_replace = random.sample(numbers, replacement_count)
        
        for old_num in numbers_to_replace:
            if number_pool:
                new_num = str(random.choice(number_pool))
                number_pool.remove(int(new_num))
                # 替换左右两边的数字
                left = left.replace(old_num, new_num, 1)
                right = right.replace(old_num, new_num, 1)
        
        # 返回替换后的公式
        return f"{left} = {right}" if right else left



    def replace_with_number(self, formula):
        formula = str(formula)
        
        if '=' in formula:
            left, right = formula.split('=', 1)
            left = left.strip()
            right = right.strip()
        
            left_expr = sp.sympify(left, locals=self.local_dict)
            right_expr = sp.sympify(right, locals=self.local_dict)
            
            all_symbols = list(set(left_expr.free_symbols) | set(right_expr.free_symbols))
            
            if not all_symbols:
                return formula
            
            symbol_to_replace = random.choice(all_symbols)
            number = random.randint(1, 10)
            
            new_left = left_expr.subs({symbol_to_replace: number})
            new_right = right_expr.subs({symbol_to_replace: number})
            
            return f"{new_left} = {new_right}"
        
        # 处理非等式表达式
        expr = sp.sympify(formula, locals=self.local_dict)
        symbols = list(expr.free_symbols)
        
        if not symbols:
            return formula
        
        symbol_to_replace = random.choice(symbols)
        number = random.randint(1, 10)
        
        new_expr = expr.subs({symbol_to_replace: number})
        return str(new_expr)


    def replace_with_variable(self, formula, variables):
        # 处理等式情况
        if isinstance(formula, str) and '=' in formula:
            left, right = formula.split('=', 1)
            left_expr = sp.sympify(left.strip(), locals=self.local_dict)
            right_expr = sp.sympify(right.strip(), locals=self.local_dict)
            equation = sp.Eq(left_expr, right_expr)
        else:
            equation = sp.sympify(formula, locals=self.local_dict)
        
        if not variables:
            return str(equation)
        
        # 执行变量替换
        old_var = random.choice(list(variables))
        new_var = sp.Symbol(random.choice(self.variable_library))
        new_equation = equation.subs(old_var, new_var)
        
        # 返回字符串形式的等式
        if isinstance(new_equation, sp.Eq):
            return f"{new_equation.lhs} = {new_equation.rhs}"
        return str(new_equation)

   

    def replace_with_formula(self, formula, all_tricks):
        # 统一处理字符串输入
        formula_str = str(formula)
        
        # 解析原始公式
        if '=' in formula_str:
            orig_left, orig_right = formula_str.split('=', 1)
            orig_left_expr = sp.sympify(orig_left.strip(), locals=self.local_dict)
            orig_right_expr = sp.sympify(orig_right.strip(), locals=self.local_dict)
        else:
            orig_expr = sp.sympify(formula_str, locals=self.local_dict)
            orig_left_expr = orig_expr
            orig_right_expr = sp.Integer(0)
        
        # 获取原始公式变量
        all_vars = list(set(orig_left_expr.free_symbols) | set(orig_right_expr.free_symbols))
        
        # 遍历所有技巧公式寻找匹配
        valid_replacements = []
        for trick_formula in all_tricks.keys():
            if '=' in trick_formula:
                trick_left, trick_right = trick_formula.split('=', 1)
                trick_left_expr = sp.sympify(trick_left.strip(), locals=self.local_dict)
                trick_right_expr = sp.sympify(trick_right.strip(), locals=self.local_dict)
                
                trick_vars = list(set(trick_left_expr.free_symbols) | set(trick_right_expr.free_symbols))
                
                # 变量数量匹配时尝试映射
                if len(trick_vars) == len(all_vars):
                    from itertools import permutations
                    for perm in permutations(trick_vars, len(all_vars)):
                        var_map = dict(zip(all_vars, perm))
                        
                        # 检查是否匹配原始公式结构
                        if (orig_left_expr.subs(var_map) == trick_left_expr or 
                            orig_left_expr.subs(var_map) == trick_right_expr):
                            valid_replacements.append((trick_formula, var_map))
        
        # 执行替换
        if valid_replacements:
            chosen_formula, var_map = random.choice(valid_replacements)
            left_side, right_side = chosen_formula.split('=', 1)
            
            # 反转变量映射
            reverse_map = {v: k for k, v in var_map.items()}
            new_left = sp.sympify(left_side.strip()).subs(reverse_map)
            new_right = sp.sympify(right_side.strip()).subs(reverse_map)
            
            return f"{new_left} = {new_right}"
        
        return formula_str



    def swap_terms(self, expr, variables, pos_info=None):
        """交换项的位置（支持递归）"""
        # try:
        if pos_info is None:
            pos_info = []
        
        # 将表达式分解为项
        if isinstance(expr, sp.Add):
            terms = list(expr.args)
        elif isinstance(expr, sp.Mul):
            terms = list(expr.args)
        else:
            # 如果不是加法或乘法表达式，直接返回
            return expr, []
        
        if len(terms) < 2:
            return expr, []
        
        # 记录修改的结构
        modified_structure = {}
        
        # 随机决定交换次数
        swap_times = random.randint(1, min(5, len(terms)))
        
        for i in range(swap_times):
            # 随机选择要交换的两个项
            idx1, idx2 = random.sample(range(len(terms)), 2)
            
            # 交换项
            terms[idx1], terms[idx2] = terms[idx2], terms[idx1]
            
            # 记录结构变化
            current_pos = pos_info + [i]
            modified_structure[tuple(current_pos)] = {
                'swapped_indices': [idx1, idx2],
                'terms': [str(term) for term in terms]
            }
            
            # 递归处理复合项
            for j, term in enumerate(terms):
                if isinstance(term, (sp.Add, sp.Mul)):
                    new_pos_info = current_pos + [j]
                    new_term, sub_changes = self.swap_terms(
                        term,
                        variables,
                        new_pos_info
                    )
                    if sub_changes:
                        modified_structure.update(sub_changes)
                    terms[j] = new_term
        if isinstance(expr, sp.Add):
            new_expr = sum(terms)
        else:  # sp.Mul
            new_expr = terms[0]
            for term in terms[1:]:
                new_expr *= term
        
        return new_expr, modified_structure
        



    def swap_mul_terms(self, expr):
            # 如果输入是字符串，先转换为sympy表达式
        if isinstance(expr, str):
            expr = sp.sympify(expr, locals=self.local_dict)
        if isinstance(expr, sp.Mul):
            factors = list(expr.args)
            if len(factors) >= 2:
                # 随机选择两个位置进行交换
                idx1, idx2 = random.sample(range(len(factors)), 2)
                factors[idx1], factors[idx2] = factors[idx2], factors[idx1]
                
                # 重建表达式
                new_expr = factors[0]
                for factor in factors[1:]:
                    new_expr *= factor
                return new_expr
        # 如果不是乘法表达式或只有一个因子，返回原表达式
        return expr
        


    def set_allowed_operations(self, allowed_operations):
        self.operations_list = allowed_operations



    def process_and_compare_formula(self, original_formula_str, modified_formula_str=None):
        if True:
            result = {
                "original_structure": None,
                "modified_structure": None,
                "edit_distance": None
            }
            
            original_expr = self.parse_formula(original_formula_str)
            if original_expr is not None:
                result["original_structure"] = self.record_structure(original_expr)
            
            if modified_formula_str:
                modified_expr = self.parse_formula(modified_formula_str)
                if modified_expr is not None:
                    modified_structure = self.record_structure(modified_expr)
                    result["modified_structure"] = modified_structure
                    
                    if result["original_structure"] is not None:
                        result["edit_distance"] = self.compute_edit_distance(
                            result["original_structure"],
                            modified_structure
                        )
            
            return result
        



    def record_structure(self, expr):
        #结构记录函数
            structure = {}
            
            def process_term(term, current_dict, index):
                if isinstance(term, (sp.Add, sp.Mul, sp.sin, sp.cos, sp.tan, sp.cot)):
                    current_dict[str(index)] = {
                        'type': term.__class__.__name__,
                        'content': str(term),
                        'terms': {}
                    }
                    if hasattr(term, 'args'):
                        for i, subterm in enumerate(term.args):
                            process_term(subterm, current_dict[str(index)]['terms'], i)
                else:
                    current_dict[str(index)] = {
                        'type': 'Basic',
                        'content': str(term)
                    }
                
            if isinstance(expr, (sp.Add, sp.Mul, sp.sin, sp.cos, sp.tan, sp.cot)):
                for i, term in enumerate(expr.args):
                    process_term(term, structure, i)
            else:
                process_term(expr, structure, 0)
                
            return structure
    


    def compute_edit_distance(self, struct1, struct2):
        #计算两个结构之间的编辑距离
        def get_structure_sequence(struct):
            #结构转换为了序列
            sequence = []
            
            def traverse(d):
                if isinstance(d, dict):
                    for key in sorted(d.keys()):  # 确保顺序一致
                        if isinstance(d[key], dict) and 'type' in d[key]:
                            sequence.append(f"{d[key]['type']}_{d[key]['content']}")
                            if 'terms' in d[key]:
                                traverse(d[key]['terms'])
                        elif isinstance(d[key], dict):
                            traverse(d[key])
            
            traverse(struct)
            return sequence
            
        # 获取两个结构的序列表示
        seq1 = get_structure_sequence(struct1)
        seq2 = get_structure_sequence(struct2)
        
        # 算编辑距离
        return fuzz.ratio(''.join(seq1), ''.join(seq2))


    def execute_functions(self, user_formula, times=None):
        print(f"\n=== 开始执行变换 ===")
        print(f"输入公式: {user_formula}")
        
        if times is None:
            times = random.randint(1, 10)
        
        results = []
        score = 0

        # 只在开始时解析一次表达式
        expr, variables = self.parse_user_formula(user_formula)
        if expr is None:
            print(f"无法解析公式: {user_formula}")
            return []
        
        # 使用解析后的表达式
        current_expr = expr.rhs if isinstance(expr, sp.Eq) else expr
        
        result = {
            "formula": {
                "left": str(expr.lhs) if isinstance(expr, sp.Eq) else str(expr),
                "right": str(expr.rhs) if isinstance(expr, sp.Eq) else str(expr)
            },
            "tricks": [],
            "complexity": {
                "edit_distance": None,
                "score": 0
            }
        }
        
        # 执行变换操作
        for _ in range(times):
            # 第一阶段
            pre_transformed = current_expr
            first_phase_ops = [4, 5, 6, 7, 8]
            
            for _ in range(5):
                operation = random.choice(first_phase_ops)
                
                if operation == 4:
                    pre_transformed = self.multiply_with_num(pre_transformed)
                    score += 1
                # elif operation == 5:
                #     pre_transformed = self.num_replace_with_num(pre_transformed)
                elif operation == 6:
                    pre_transformed = self.swap_mul_terms(pre_transformed)
                    score += 1
                elif operation == 7:
                    pre_transformed, _ = self.swap_terms(pre_transformed, variables)
                    score += 1
                elif operation == 8:
                    pre_transformed = self.add_elements(pre_transformed)
                    score += 1
            
            # 第二阶段
            post_transformed = pre_transformed
            second_phase_ops = [1, 2]
            
            for _ in range(1):
                operation = random.choice(second_phase_ops)
                
                if operation == 1:
                    post_transformed = self.replace_with_number(post_transformed)
                    if post_transformed is not None:
                        score += 1
                elif operation == 2:
                    post_transformed = self.replace_with_variable(post_transformed, variables)
                    if post_transformed is not None:
                        score += 1
            
            if post_transformed is not None:
                result['tricks'].append({
                    "operation": "combined_operations",
                    "formula_after": str(post_transformed)
                })
                result['complexity']['score'] = score
                current_expr = post_transformed
        
        results.append(result)
        return results

    def calculate_formula_replace_score(self, orig_formula, formula):
        #计算公式替换的分数
        try:
            orig_vars = list(orig_formula.free_symbols)
            formula_vars = list(formula.free_symbols)
            overlap_vars = [var for var in orig_vars if var in formula_vars]
            new_vars = [var for var in formula_vars if var not in orig_vars]
            return len(overlap_vars) - len(orig_vars) + len(new_vars)
        except Exception as e:
            print(f"计算替换分数时出错: {str(e)}")
            return 0