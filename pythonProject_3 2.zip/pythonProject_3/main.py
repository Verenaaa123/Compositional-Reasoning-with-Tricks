from trick_rules.rule_module import FormulaManipulator
from config import all_tricks  # 从config导入
import argparse
import json
import sympy
import random

from trick_rules import *
from fusion.operations import Operations

# 三角函数符号
alpha, beta = sympy.symbols('α β')
# 基础代数符号
a, b, n, pi, k = sympy.symbols('a b n pi k')
# 数列相关符号
S_n, a_1, q, d = sympy.symbols('S_n a_1 q d')

def tricks_fusion():
    
    formula_manipulator = FormulaManipulator()
    all_rules_results = {}
    
    for trick_expr, rule_name in all_tricks.items():
        if isinstance(rule_name, str) and trick_expr:
            print(f"开始处理规则: {rule_name}")
            print(f"处理表达式: {trick_expr}")
            
            # 存储该规则的所有结果
            all_results = []
            
            # 对每个技巧执行10次变换
            for transformation_round in range(10):
                print(f"执行第 {transformation_round + 1} 轮变换...")
                
                # 随机决定本轮执行1-10次操作
                num_operations = random.randint(1, 10)
                print(f"本轮将执行 {num_operations} 次操作...")
                
                # 执行变换操作
                results = formula_manipulator.execute_functions(trick_expr, times=num_operations)
                
                # 将结果添加到列表中
                if results:
                    all_results.append({
                        "transformation_round": transformation_round + 1,
                        "num_operations": num_operations,
                        "results": results
                    })
            
            # 将该规则的所有结果添加到总结果字典中
            all_rules_results[rule_name] = {
                "rule_name": rule_name,
                "original_expression": trick_expr,
                "executions": all_results
            }
            
            print(f"完成 {rule_name} 的融合")
    
    # 保存所有结果到一个文件
    filepath = '/Users/wyl/Desktop/pythonProject_3/data/tricks/fusion_results_all.json'
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(all_rules_results, f, ensure_ascii=False, indent=4)
    print(f"所有规则的融合结果已保存到 {filepath}")


def tricks_construction(trick_name=None):
    """
    构建规则的变换，始终处理所有tricks
    Args:
        trick_name: 参数保留但不再使用
    """
    # 创建 Operations 实例
    ops = Operations()
    
    # 读取fusion结果
    fusion_file = f'/Users/wyl/Desktop/pythonProject_3/data/tricks/fusion_results_all.json'
    try:
        with open(fusion_file, 'r', encoding='utf-8') as f:
            fusion_results = json.load(f)
    except Exception as e:
        print(f"读取fusion结果失败: {str(e)}")
        fusion_results = {}
    
    # 处理所有tricks
    all_formulas = {}
    
    # 收集所有需要处理的公式
    for formula, rule in all_tricks.items():
        all_formulas[formula] = rule
        
        # 从fusion结果中添加相关的变换结果
        if fusion_results and rule in fusion_results:
            rule_results = fusion_results[rule]
            if isinstance(rule_results, dict) and 'executions' in rule_results:
                for execution in rule_results['executions']:
                    for result in execution.get('results', []):
                        for trick in result.get('tricks', []):
                            if isinstance(trick, dict) and 'formula_after' in trick:
                                all_formulas[trick['formula_after']] = rule
    
    try:
        # 对每个公式执行operations
        results = {}
        for formula, rule in all_formulas.items():
            # 使用execute_operations处理每个公式
            operation_results = ops.execute_operations(formula, all_formulas)
            if formula not in results:
                results[formula] = {
                    "rule": rule,
                    "operations": operation_results
                }
        
        # 保存结果到文件
        file_dir = '/Users/wyl/Desktop/pythonProject_3/data/composition'
        filename = 'construct_result_all.json'  # 始终使用相同的文件名
        filepath = f'{file_dir}/{filename}'
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump({
                    "processed_tricks": list(all_tricks.keys()),  # 包含所有tricks
                    "results": results
                }, f, ensure_ascii=False, indent=4)
            print(f"Construction results saved in {filepath}")
        except Exception as e:
            print(f"保存结果时出错: {str(e)}")
            
    except Exception as e:
        print(f"执行操作时出错: {str(e)}")

# 命令行参数解析
parser = argparse.ArgumentParser(description='Template scripts. function 1: Hello World')
parser.add_argument('--function', type=str, default=0, help='use this to specify function!')
parser.add_argument('--v1', type=int, default=0, help='int value')
parser.add_argument('--s1', type=str, default='none', help='string 1')

args = parser.parse_args()

if __name__ == "__main__":
    if args.function == '0':
        print("no function indicate")
    elif args.function == '1':
        # 如果没有指定规则名称，使用默认值
        rule_name = args.s1 if args.s1 != 'none' else "squa_diff"
        tricks_construction(rule_name)
    elif args.function == '2':
        tricks_fusion() 