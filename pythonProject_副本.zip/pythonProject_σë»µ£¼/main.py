from trick_rules.rule_module import FormulaManipulator
import argparse
import json
import sympy
import random

from trick_rules import *
from fusion.operations import Operations

# 三角函数符号
alpha, beta = sympy.symbols('α β')
# 基础代数符号
a, b, n, pi, k = sympy.symbols('a b n pi k')
# 数列相关符号
S_n, a_1, q, d = sympy.symbols('S_n a_1 q d')

# 保留原始公式字典
all_tricks = {
        f"({a}+{b})*({a}-{b})={a}**{2}-{b}**2":"squa_diff",
        f"({a}+{b})**2={a}**2+2*{a}*{b}+{b}**2":"sum_of_perf_squa_n_diff",
        f"({a}-{b})**2={a}**2-2*{a}*{b}+{b}**2": "sum_of_perf_squa_n_diff",
        f"({a}+{b})**3={a}**3+3*{a}**2*{b}+3*{a}*{b}**2+{b}**3": "perf_cube_n_the_form",
        f"({a}-{b})**3={a}**3-3*{a}**2*{b}+3*{a}*{b}**2-{b}**3":"perf_cube_n_the_form",
        f"{a}**3+{b}**3=({a}+{b})({a}**2-{a}*{b}+{b}**2)": "cubi_sum_diff",
        f"{a}**3-{b}**3=({a}+{b})({a}**2+{a}*{b}+{b}**2)": "cubi_sum_diff",

        f"{S_n} = {n} * {a_1} + ({n} * ({n} - 1) * {d}) / 2":"arit_prog",
        f"({a_1}*(1 - {q}**{n}))/(1 - {q})": "geom_prog",

        f"sin(2*{k}*{pi} + {alpha}) == sin({alpha})": "indu_form",
        f"sin(-{alpha}) == -sin({alpha})": "indu_form",
        f"sin(2*{pi} - {alpha}) == -sin({alpha})": "indu_form",
        f"sin({pi}/2 + {alpha}) == cos({alpha})": "indu_form",
        f"cos(2*{k}*pi + {alpha}) == cos({alpha})": "indu_form",
        f"cos(-{alpha}) == cos({alpha})": "indu_form",
        f"cos(2*{pi} - {alpha}) == cos({alpha})": "indu_form",
        f"sin({pi}/2 - {alpha}) == cos({alpha})": "indu_form",
        f"tan(2*{k}*{pi} + {alpha}) == tan({alpha})": "indu_form",
        f"tan(-{alpha}) == -tan({alpha})": "indu_form",
        f"tan(2*{pi} - {alpha}) == -tan({alpha})": "indu_form",
        f"cos({pi}/2 + {alpha}) == -sin({alpha})": "indu_form",
        f"cot(2*{k}*{pi} + {alpha}) == cot({alpha})": "indu_form",
        f"cot(-{alpha}) == -cot({alpha})": "indu_form",
        f"cot(2*{pi} - {alpha}) == -cot({alpha})": "indu_form",
        f"cos({pi}/2 - {alpha}) == sin({alpha})": "indu_form",
        f"sin({pi} + {alpha}) == -sin({alpha})": "indu_form",
        f"sin({pi} - {alpha}) == sin({alpha})": "indu_form",
        f"cos({pi} + {alpha}) == -cos({alpha})": "indu_form",
        f"cos({pi} - {alpha}) == -cos({alpha})": "indu_form",
        f"tan({pi} + {alpha}) == tan({alpha})": "indu_form",
        f"tan({pi} - {alpha}) == -tan({alpha})": "indu_form",
        f"cot({pi} + {alpha}) == cot({alpha})": "indu_form",
        f"cot({pi} - {alpha}) == -cot({alpha})": "indu_form",
        f"cot({pi}/2 + {alpha}) == -tan({alpha})": "indu_form",
        f"cot({pi}/2 - {alpha}) == cot({alpha})": "indu_form",
        f"tan({pi}/2 + {alpha}) == -cot({alpha})": "indu_form",
        f"tan({pi}/2 - {alpha}) == cot({alpha})": "indu_form",

        f"cos({alpha} + {beta}) == cos({alpha}) * cos({beta}) - sin({alpha}) * sin({beta})": "sum_n_diff_of_two_angl",
        f"cos({alpha} - {beta}) == cos({alpha}) * cos({beta}) + sin({alpha}) * sin({beta})": "sum_n_diff_of_two_angl",
        f"sin({alpha} + {beta}) == sin({alpha}) * cos({beta}) + cos({alpha}) * sin({beta})": "sum_n_diff_of_two_angl",
        f"sin({alpha} - {beta}) == sin({alpha}) * cos({beta}) - cos({alpha}) * sin({beta})": "sum_n_diff_of_two_angl",
        
        f"sin({alpha}) * cos({beta}) == (sin({alpha} + {beta}) + sin({alpha} - {beta})) / 2": "prod_n_diff",
        f"cos({alpha}) * sin({beta}) == (sin({alpha} + {beta}) - sin({alpha} - {beta})) / 2": "prod_n_diff",
        f"cos({alpha}) * cos({beta}) == (cos({alpha} + {beta}) + cos({alpha} - {beta})) / 2": "prod_n_diff",
        f"sin({alpha}) * sin({beta}) == -(cos({alpha} + {beta}) - cos({alpha} - {beta})) / 2": "prod_n_diff",
        
        f"sin({alpha}) + sin({beta}) == 2 * sin(({alpha} + {beta}) / 2) * cos(({alpha} - {beta}) / 2)": "sum_n_diff_prod",
        f"sin({alpha}) - sin({beta}) == 2 * cos(({alpha} + {beta}) / 2) * sin(({alpha} - {beta}) / 2)": "sum_n_diff_prod",
        f"cos({alpha}) + cos({beta}) == 2 * cos(({alpha} + {beta}) / 2) * cos(({alpha} - {beta}) / 2)": "sum_n_diff_prod",
        f"cos({alpha}) - cos({beta}) == -2 * sin(({alpha} + {beta}) / 2) * sin(({alpha} - {beta}) / 2)": "sum_n_diff_prod",
        
        # f"{a}-({a}**(-1)+({b}**(-1)-{a})**(-1))**(-1) = {a}*{b}*{a}": "hua_equ",
        # f"{a} = ({b}**(-1)-({a}-1)**(-1)*{b}**(-1)*({a}-1))({a}**(-1)*{b}**(-1)*({a}-1))*(-1)": "hua_equ_2"
}

def tricks_fusion():
    """
    遍历所有技巧并执行融合操作，每个技巧执行10次，所有结果存储在同一个文件中
    """
    formula_manipulator = FormulaManipulator()
    all_rules_results = {}  # 存储所有规则的结果
    
    for trick_expr, rule_name in all_tricks.items():
        if isinstance(rule_name, str):
            # try:
                print(f"开始处理规则: {rule_name}")
                print(f"处理表达式: {trick_expr}")
                
                # 使用 FormulaManipulator 解析表达式
                expr, variables = formula_manipulator.parse_user_formula(trick_expr)
                if expr is None:
                    continue
                
                # 存储该规则的所有结果
                all_results = []
                
                # 执行10次变换
                for i in range(10):
                    if i == 5:
                        import pdb; pdb.set_trace()
                    print(f"执行第 {i+1} 次变换...")
                    
                    # 设置每次变换的次数范围
                    min_transforms = 5
                    max_transforms = 15
                    num_transforms = random.randint(min_transforms, max_transforms)
                    
                    # 执行变换并获取结果
                    results = formula_manipulator.execute_functions(trick_expr, times=num_transforms)
                    
                    # 将本次执行的结果添加到列表中
                    if results:
                        all_results.append({
                            "execution_id": i + 1,
                            "transforms_count": num_transforms,
                            "result": results[0] if results else {}
                        })
                
                # 将该规则的所有结果添加到总结果字典中
                all_rules_results[rule_name] = {
                    "rule_name": rule_name,
                    "original_expression": trick_expr,
                    "executions": all_results
                }
                
                print(f"完成 {rule_name} 的融合")
                    
            # except Exception as e:
            #     print(f"处理 {rule_name} 时出错: {str(e)}")
    
    # 保存所有结果到一个文件
    filepath = '/Users/wyl/Desktop/pythonProject_副本/data/tricks/fusion_results_all.json'
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(all_rules_results, f, ensure_ascii=False, indent=4)
        print(f"所有规则的融合结果已保存到 {filepath}")
    except Exception as e:
        print(f"保存结果失败: {str(e)}")


def tricks_construction(trick_name):
    """
    构建特定规则的变换
    Args:
        trick_name: 规则名称（字符串）
    """
    # 创建 Operations 实例
    ops = Operations()
    
    # 获取原始公式
    original_formula = None
    for formula, rule in all_tricks.items():
        if rule == trick_name:
            original_formula = formula
            break
            
    if original_formula is None:
        print(f"未找到名为 {trick_name} 的公式")
        return
        
    # 读取fusion结果
    fusion_file = f'/Users/wyl/Desktop/pythonProject_副本/data/tricks/fusion_results_all.json'
    try:
        with open(fusion_file, 'r', encoding='utf-8') as f:
            fusion_results = json.load(f)
    except Exception as e:
        print(f"读取fusion结果失败: {str(e)}")
        fusion_results = {}
        
    # 合并原始公式和fusion结果
    all_formulas = {original_formula: trick_name}  # 原始公式
    if fusion_results:
        # 遍历结果寻找 formula_after
        for result in fusion_results.values():
            if isinstance(result, dict):
                # 检查tricks列表中的formula_after
                tricks = result.get('tricks', [])
                for trick in tricks:
                    if isinstance(trick, dict) and 'formula_after' in trick:
                        all_formulas[trick['formula_after']] = trick_name
    
    try:
        # 对每个公式执行operations
        results = {}
        for formula in all_formulas:
            # 使用execute_operations处理每个公式
            operation_results = ops.execute_operations(formula, all_formulas)
            results[formula] = operation_results

        # 保存结果到文件
        file_dir = '/Users/wyl/Desktop/pythonProject_副本/data/composition'
        filepath = f'{file_dir}/construct_result_{trick_name}.json'
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump({
                    "trick_name": trick_name,
                    "original_formula": original_formula,
                    "results": results
                }, f, ensure_ascii=False, indent=4)
            print(f"Construction result saved in {filepath}")
        except Exception as e:
            print(f"保存结果时出错: {str(e)}")
            
    except Exception as e:
        print(f"执行操作时出错: {str(e)}")

# 命令行参数解析
parser = argparse.ArgumentParser(description='Template scripts. function 1: Hello World')
parser.add_argument('--function', type=str, default=0, help='use this to specify function!')
parser.add_argument('--v1', type=int, default=0, help='int value')
parser.add_argument('--s1', type=str, default='none', help='string 1')

args = parser.parse_args()

if __name__ == "__main__":
    if args.function == '0':
        print("no function indicate")
    elif args.function == '1':
        # 如果没有指定规则名称，使用默认值
        rule_name = args.s1 if args.s1 != 'none' else "squa_diff"
        tricks_construction(rule_name)
    elif args.function == '2':
        tricks_fusion() 