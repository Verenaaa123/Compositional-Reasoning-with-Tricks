import sympy as sp
from sympy import expand, sympify
import random
import re
from itertools import permutations
from trick_rules.rule_module import FormulaManipulator



class Operations():
    #import pdb;
    def __init__(self):
        self.reset_counters()
        self.operations_list = [1, 2, 3, 4]  # 简化操作列表
        self.formula_manipulator = FormulaManipulator()
        
    def reset_counters(self):
        self.counters = {
            'find_right_operand': 0,
            'concatenate_formulas': 0,
            'extract_factors': 0,
            'generate_formulas': 0,
        }


    def find_right_operand(self, expression):
        try:
            if isinstance(expression, sp.Eq):
                expression = str(expression.rhs)  # 只处理等式右边
            else:
                expression = str(expression)
                
            expanded_result = []
            
            # 尝试展开表达式的不同部分
            try:
                expr = sympify(expression)
                expanded = expand(expr)
                expanded_result.append(str(expanded))
            except:
                pass
                
            self.counters['find_right_operand'] += 1
            return expanded_result
            
        except Exception as e:
            print(f"查找右操作数时出错: {str(e)}")
            return []


    #collect()

    #拼接
    def concatenate_formulas(self, formula, all_tricks):
        try:
            # 将输入公式转换为字符串并分离左右两边
            if isinstance(formula, sp.Eq):
                left_side = str(formula.lhs)
                right_side = str(formula.rhs)
            else:
                # 如果是字符串，尝试分离等号两边
                parts = str(formula).split('==')
                left_side = parts[0].strip()
                right_side = parts[1].strip() if len(parts) > 1 else str(formula)
            
            max_additions = min(len(all_tricks), 3)
            num_additions = random.randint(1, max_additions)
            
            # 分别组合左右两边
            combined_left = left_side
            combined_right = right_side
            
            available_formulas = list(all_tricks.keys())
            for _ in range(num_additions):
                if available_formulas:
                    random_formula = random.choice(available_formulas)
                    # 分离选中的公式的左右两边
                    if '==' in random_formula:
                        rf_parts = random_formula.split('==')
                        combined_left = f"({combined_left}) + ({rf_parts[0].strip()})"
                        combined_right = f"({combined_right}) + ({rf_parts[1].strip()})"
                    else:
                        # 如果没有等号，整体相加
                        combined_left = f"({combined_left}) + ({random_formula})"
                        combined_right = f"({combined_right}) + ({random_formula})"
                    available_formulas.remove(random_formula)
                
                self.counters['concatenate_formulas'] += 1
            
            # 重新组合成等式
            return f"{combined_left} == {combined_right}"
            
        except Exception as e:
            print(f"组合公式时出错: {str(e)}")
            return str(formula)


    # 穷举
    def extract_factors(self, formula):
        try:
            if isinstance(formula, sp.Eq):
                formula = str(formula)
                
            # 使用正则表达式匹配括号内的内容
            factors = re.findall(r'\((.*?)\)', formula)
            
            self.counters['extract_factors'] += 1
            return factors
            
        except Exception as e:
            print(f"提取因子时出错: {str(e)}")
            return []


    def generate_formulas(self, formula):
        try:
            if isinstance(formula, sp.Eq):
                formula = str(formula)
                
            factors = self.extract_factors(formula)
            results = []
            
            # 生成所有可能的因式排列
            if factors:
                for perm in permutations(factors):
                    # 重新构建公式
                    new_formula = '({})'.format(')('.join(perm))
                    results.append(new_formula)
            
            self.counters['generate_formulas'] += 1
            return results[0] if results else str(formula)
            
        except Exception as e:
            print(f"生成公式时出错: {str(e)}")
            return str(formula)


    def execute_operations(self, user_formula, all_tricks):
        results = {}
        times = random.randint(1, 10)
        
        for i in range(times):
            result = {
                "formula": {
                    "left": None,
                    "right": None,
                },
                'fusion_operands': [],
                'complexity': {
                    'find_right_operand': None,
                    'concatenate_formulas': None,
                    'extract_factors': None,
                    'generate_formulas': None,
                },
            }
            
            try:
                # 解析公式
                formula = self.formula_manipulator.parse_user_formula(user_formula)
                if formula is None:
                    continue
                    
                # 分离左右两边
                result['formula']['left'] = str(self.formula_manipulator.separate_left(user_formula))
                result['formula']['right'] = str(self.formula_manipulator.separate_right(user_formula))
                
                # 随机选择一个操作
                operation = random.choice(self.operations_list)
                operand_result = None
                
                if operation == 1:
                    operand_result = self.find_right_operand(formula)
                elif operation == 2:
                    operand_result = self.concatenate_formulas(formula, all_tricks)
                elif operation == 3:
                    operand_result = self.extract_factors(formula)
                elif operation == 4:
                    operand_result = self.generate_formulas(formula)
                
                if operand_result is not None:
                    result['fusion_operands'].append(str(operand_result))
                    
                result['complexity'] = self.get_counters()
                results[str(i)] = result
                
            except Exception as e:
                print(f"执行操作时出错: {str(e)}")
                continue
                
        return results


    def get_counters(self):
            return self.counters


manipulator = FormulaManipulator()





