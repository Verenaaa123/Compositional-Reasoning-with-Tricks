import sympy as sp
from sympy import factor
import random
from sympy import Poly
import re
#from thefuzz import fuzz 
from config import all_tricks


class FormulaManipulator:
    def __init__(self):
        self.variable_library = list('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz') + \
                               [chr(i) for i in range(0x03B1, 0x03C9 + 1)]
        self.operations_list = [1, 2, 3, 4, 5, 6, 7, 8]


    # 转sympy+返回变量名
    def parse_user_formula(self, formula_str):
        # try:
        #import pdb; pdb.set_trace()

        print(f"收到的原始输入: '{formula_str}'")
        print(f"输入类型: {type(formula_str)}")
        
        if not isinstance(formula_str, str):
            formula_str = str(formula_str)
            print(f"转换后的字符串: '{formula_str}'")
        
        # 检查是否为空或只包含空白字符
        if not formula_str or formula_str.isspace():
            print("错误：输入为空或只包含空白字符")
            return None, []
        
        # 处理双等号
        formula_str = formula_str.replace('==', '=')
        
        # 替换希腊字母
        formula_str = formula_str.replace('α', 'alpha')
        formula_str = formula_str.replace('β', 'beta')
        formula_str = formula_str.replace('π', 'pi')
        
        # 创建本地变量字典
        local_dict = {
            'sin': sp.Function('sin'),
            'cos': sp.Function('cos'),
            'tan': sp.Function('tan'),
            'cot': sp.Function('cot'),
            'pi': sp.Symbol('pi'),
            'alpha': sp.Symbol('alpha'),
            'beta': sp.Symbol('beta'),
            'a': sp.Symbol('a'),
            'b': sp.Symbol('b'),
            'n': sp.Symbol('n'),
            'k': sp.Symbol('k'),
            'S_n': sp.Symbol('S_n'),
            'a_1': sp.Symbol('a_1'),
            'q': sp.Symbol('q'),
            'd': sp.Symbol('d')
        }
        
        # 预处理三角函数的幂运算
        pattern = r'(sin|cos|tan|cot)(?:\*\*(\d+))?\(([^()]+)\)'
        max_iterations = 10
        iteration = 0
        
        while re.search(pattern, formula_str) and iteration < max_iterations:
            formula_str = re.sub(pattern, 
                lambda m: f"({m.group(1)}({m.group(3)})){'**' + m.group(2) if m.group(2) else ''}", 
                formula_str)
            iteration += 1
        
        # 处理等式
        if '=' in formula_str:
            left_side, right_side = formula_str.split('=', 1)
                # 清理空白字符并确保表达式有效
            left_side = left_side.strip()
            right_side = right_side.strip()
            
            if not left_side or not right_side:
                print("等式的左边或右边为空")
                return None, []
                
            left_expr = sp.sympify(left_side, locals=local_dict)
            right_expr = sp.sympify(right_side, locals=local_dict)
            expr = sp.Eq(left_expr, right_expr)
     
        else:
                # 清理空白字符
            formula_str = formula_str.strip()
            if not formula_str:
                print("表达式为空")
                return None, []
                
            expr = sp.sympify(formula_str, locals=local_dict)
        
        # 获取表达式中的变量
        variables = list(expr.free_symbols)
        
        #import pdb; pdb.set_trace()
        return expr, variables
        
        # except Exception as e:
        #     print(f"解析公式时出错: {str(e)}")
        #     print(f"问题公式: {formula_str}")
        #     return None, []




    def separate_left(self, formula):
        try:
            formula = str(formula)
            formula = formula.replace('==', '=')
            sides = re.split(r'=(?!=)', formula)
            
            # 创建本地变量字典
            local_dict = {
                'sin': sp.Function('sin'),
                'cos': sp.Function('cos'),
                'tan': sp.Function('tan'),
                'cot': sp.Function('cot'),
                'pi': sp.Symbol('pi'),
                'alpha': sp.Symbol('alpha'),
                'beta': sp.Symbol('beta'),
                'a': sp.Symbol('a'),
                'b': sp.Symbol('b'),
                'n': sp.Symbol('n'),
                'k': sp.Symbol('k'),
                'S_n': sp.Symbol('S_n'),
                'a_1': sp.Symbol('a_1'),
                'q': sp.Symbol('q'),
                'd': sp.Symbol('d')
            }
            
            if len(sides) == 2:
                return sp.sympify(sides[0].strip(), locals=local_dict)
            return sp.sympify(formula, locals=local_dict)
        except Exception as e:
            print(f"分离左式时出错: {str(e)}")
            return None



    def separate_right(self, formula):
        try:
            formula = str(formula)
            formula = formula.replace('==', '=')
            sides = re.split(r'=(?!=)', formula)
            
            # 创建本地变量字典
            local_dict = {
                'sin': sp.Function('sin'),
                'cos': sp.Function('cos'),
                'tan': sp.Function('tan'),
                'cot': sp.Function('cot'),
                'pi': sp.Symbol('pi'),
                'alpha': sp.Symbol('alpha'),
                'beta': sp.Symbol('beta'),
                'a': sp.Symbol('a'),
                'b': sp.Symbol('b'),
                'n': sp.Symbol('n'),
                'k': sp.Symbol('k'),
                'S_n': sp.Symbol('S_n'),
                'a_1': sp.Symbol('a_1'),
                'q': sp.Symbol('q'),
                'd': sp.Symbol('d')
            }
            
            if len(sides) == 2:
                return sp.sympify(sides[1].strip(), locals=local_dict)
            return sp.sympify(formula, locals=local_dict)
        except Exception as e:
            print(f"分离右式时出错: {str(e)}")
            return None



    def generate_new_formulas(expr, variables, num_samples):#变量换数字
        newFunctions = []
        for _ in range(num_samples):
            substitution = {var: random.randint(1, 20) for var in
                            random.sample(variables, random.randint(1, len(variables) - 1))}
            new_expr = expr.subs(substitution)
            newFunctions.append(str(new_expr))

        return newFunctions



    def multiply_with_num(self, formula):
        # try:
        if isinstance(formula, sp.Eq):
            left = formula.lhs  # 使用 lhs 代替 separate_left
            right = formula.rhs  # 使用 rhs 代替 separate_right
            
            # 随机生成一个乘数
            multiplier = random.randint(1, 10)
            
            # 分别对等式两边进行乘法运算
            new_left = left * multiplier
            new_right = right * multiplier
            
            # 创建新的等式
            return sp.Eq(new_left, new_right)
            
        elif isinstance(formula, (sp.Add, sp.Mul, sp.Symbol, sp.Integer, sp.Float)):
            # 处理非等式的表达式
            multiplier = random.randint(1, 10)
            return formula * multiplier
            
        return formula
            
        # except Exception as e:
        #     print(f"乘法运算失败: {str(e)}")
        #     return formula



    def add_elements(self, formula):
        # try:
        if isinstance(formula, sp.Eq):
            left = self.separate_left(formula)
            right = self.separate_right(formula)
            
            add = random.choice([True, False])
            constant = random.randint(1, 100)
            
            if add:
                new_left = left + constant
                new_right = right + constant
            else:
                new_left = left - constant
                new_right = right - constant
            
            return sp.Eq(new_left, new_right)
        return formula
        # except Exception as e:
        #     print(f"添加元素失败: {str(e)}")
        #     return formula



    def num_replace_with_num(self, formula):
        if not isinstance(formula, str):
            formula = str(formula)

        numbers = re.findall(r'\d+', formula)
        if not numbers:
            return formula
        
        number_pool = list(range(1, 101))
        replacement_count = random.randint(1, len(numbers))
        numbers_to_replace = random.sample(numbers, replacement_count)
        
        for old_num in numbers_to_replace:
            if number_pool:
                new_num = str(random.choice(number_pool))
                number_pool.remove(int(new_num))
                formula = formula.replace(old_num, new_num, 1)
        
        return formula


    def replace_with_number(self, formula):
        # try:
            if isinstance(formula, sp.Eq):
                left = formula.lhs
                right = formula.rhs
                
                # 获取等式中的所有变量
                all_symbols = list(formula.free_symbols)
                
                # 如果没有变量可替换，直接返回原式
                if not all_symbols:
                    return formula
                
                # 随机选择一个变量进行替换
                symbol_to_replace = random.choice(all_symbols)
                
                # 为选中的变量生成一个随机数
                number = random.randint(1, 10)
                
                # 创建替换字典
                substitution = {symbol_to_replace: number}
                
                # 对等式两边同时进行替换
                new_left = left.subs(substitution)
                new_right = right.subs(substitution)
                
                # 创建新的等式
                new_formula = sp.Eq(new_left, new_right)
                
                return new_formula
                
            elif isinstance(formula, (sp.Add, sp.Mul, sp.Symbol, sp.Integer, sp.Float)):
                # 处理非等式表达式
                symbols = list(formula.free_symbols)
                if not symbols:
                    return formula
                    
                # 随机选择一个变量进行替换
                symbol_to_replace = random.choice(symbols)
                number = random.randint(1, 10)
                
                # 进行替换
                return formula.subs({symbol_to_replace: number})
                
            return formula
            
        # except Exception as e:
        #     print(f"数字替换失败: {str(e)}")
        #     return formula


    def replace_with_variable(self, formula, variables):
        # try:
            if not variables:
                return formula
                
            substitution = {}
            
            # 创建替换映射
            for var in variables:
                new_var = random.choice([v for v in self.variable_library if v not in substitution.values()])
                substitution[var] = sp.Symbol(new_var)
                
            # 执行替换
            new_formula = formula
            for old_var, new_var in substitution.items():
                new_formula = new_formula.subs(old_var, new_var)
                
            return new_formula
        # except Exception as e:
        #     print(f"变量替换失败: {str(e)}")
        #     return formula

   

    def replace_with_formula(self, expr, variables):
        
        # try:
            if not variables:
                return expr, {}
            
            # 确保 expr 是 sympy 表达式
            formula_expr = expr if isinstance(expr, sp.Basic) else sp.sympify(expr)
            variables_in_formula = list(formula_expr.free_symbols)
            
            if not variables_in_formula:
                return expr, {}
            
            # 决定要替换多少个变量（1到所有变量数量之间的随机数）
            num_vars_to_replace = random.randint(1, len(variables_in_formula))
            
            # 随机选择要替换的变量
            vars_to_replace = random.sample(variables_in_formula, num_vars_to_replace)
            
            # 创建替换映射
            substitution = {}
            
            # 从 all_tricks 中选择合适的公式进行替换
            for var in vars_to_replace:
                # 过滤出等式右边的公式
                available_formulas = []
                for formula_str in all_tricks.keys():
                    try:
                        if '=' in formula_str:
                            right_side = formula_str.split('=')[1].strip()
                            parsed_expr, _ = self.parse_user_formula(right_side)
                            if parsed_expr is not None:
                                available_formulas.append(right_side)
                    except Exception:
                        continue
                
                if available_formulas:
                    # 随机选择一个公式
                    chosen_formula = random.choice(available_formulas)
                    # 解析选中的公式
                    parsed_formula, _ = self.parse_user_formula(chosen_formula)
                    if parsed_formula is not None:
                        substitution[var] = parsed_formula
            
            # 执行替换
            if substitution:
                try:
                    new_formula = formula_expr
                    for var, replacement in substitution.items():
                        new_formula = new_formula.subs(var, replacement)
                    return new_formula, substitution
                except Exception as e:
                    print(f"执行替换时出错: {str(e)}")
                    return expr, {}
            
            return expr, {}
            
        # except Exception as e:
        #     print(f"替换公式时出错: {str(e)}")
        #     return expr, {}



    def swap_terms(self, expr, variables, pos_info=None):
        """交换项的位置（支持递归）"""
        # try:
        if pos_info is None:
            pos_info = []
        
        # 将表达式分解为项
        if isinstance(expr, sp.Add):
            terms = list(expr.args)
        elif isinstance(expr, sp.Mul):
            terms = list(expr.args)
        else:
            # 如果不是加法或乘法表达式，直接返回
            return expr, []
        
        if len(terms) < 2:
            return expr, []
        
        # 记录修改的结构
        modified_structure = {}
        
        # 随机决定交换次数
        swap_times = random.randint(1, min(5, len(terms)))
        
        for i in range(swap_times):
            # 随机选择要交换的两个项
            idx1, idx2 = random.sample(range(len(terms)), 2)
            
            # 交换项
            terms[idx1], terms[idx2] = terms[idx2], terms[idx1]
            
            # 记录结构变化
            current_pos = pos_info + [i]
            modified_structure[tuple(current_pos)] = {
                'swapped_indices': [idx1, idx2],
                'terms': [str(term) for term in terms]
            }
            
            # 递归处理复合项
            for j, term in enumerate(terms):
                if isinstance(term, (sp.Add, sp.Mul)):
                    new_pos_info = current_pos + [j]
                    new_term, sub_changes = self.swap_terms(
                        term,
                        variables,
                        new_pos_info
                    )
                    if sub_changes:
                        modified_structure.update(sub_changes)
                    terms[j] = new_term
        
        # 重建表达式
        # try:
            if isinstance(expr, sp.Add):
                new_expr = sum(terms)
            else:  # sp.Mul
                new_expr = terms[0]
                for term in terms[1:]:
                    new_expr *= term
            
            return new_expr, modified_structure
                
        #     except Exception as e:
        #         print(f"建表达式时出错: {str(e)}")
        #         return expr, modified_structure
                
        # except Exception as e:
        #     print(f"交换项时出错: {str(e)}")
        #     return expr, []



    def swap_mul_terms(self, expr):
        """
        交换乘法项的位置
        Args:
            expr: sympy表达式
        Returns:
            修改后的表达式
        """
        # try:
            # 如果输入是字符串，先转换为sympy表达式
        if isinstance(expr, str):
            # 使用与parse_user_formula相同的本地字典
            local_dict = {
                'sin': sp.Function('sin'),
                'cos': sp.Function('cos'),
                'tan': sp.Function('tan'),
                'cot': sp.Function('cot'),
                'pi': sp.Symbol('pi'),
                'alpha': sp.Symbol('alpha'),
                'beta': sp.Symbol('beta'),
                'a': sp.Symbol('a'),
                'b': sp.Symbol('b'),
                'n': sp.Symbol('n'),
                'k': sp.Symbol('k'),
                'S_n': sp.Symbol('S_n'),
                'a_1': sp.Symbol('a_1'),
                'q': sp.Symbol('q'),
                'd': sp.Symbol('d')
            }
            expr = sp.sympify(expr, locals=local_dict)
        
        # 如果是乘法表达式，获取所有因子
        if isinstance(expr, sp.Mul):
            factors = list(expr.args)
            if len(factors) >= 2:
                # 随机选择两个位置进行交换
                idx1, idx2 = random.sample(range(len(factors)), 2)
                factors[idx1], factors[idx2] = factors[idx2], factors[idx1]
                
                # 重建表达式
                new_expr = factors[0]
                for factor in factors[1:]:
                    new_expr *= factor
                return new_expr
        
        # 如果不是乘法表达式或只有一个因子，返回原表达式
        return expr
        
        # except Exception as e:
        #     print(f"交换乘法项时出错: {str(e)}")
        #     return expr



    def set_allowed_operations(self, allowed_operations):
        self.operations_list = allowed_operations


    def get_operand_id(self, operand=None):
        if operand == "parse_user_formula":
            return 1
        elif operand == "":
            return 


    def process_and_compare_formula(self, original_formula_str, modified_formula_str=None):
        #改进的公式处理和比较函数
        # try:
        if True:
            result = {
                "original_structure": None,
                "modified_structure": None,
                "edit_distance": None
            }
            
            # 解析原始公式
            original_expr = self.parse_formula(original_formula_str)
            if original_expr is not None:
                result["original_structure"] = self.record_structure(original_expr)
            
            # 如果有修改后的公式，解析并比较结构
            if modified_formula_str:
                modified_expr = self.parse_formula(modified_formula_str)
                if modified_expr is not None:
                    modified_structure = self.record_structure(modified_expr)
                    result["modified_structure"] = modified_structure
                    
                    if result["original_structure"] is not None:
                        result["edit_distance"] = self.compute_edit_distance(
                            result["original_structure"],
                            modified_structure
                        )
            
            return result
        # except Exception as e:
        #     print(f"处理公式结构时出错: {str(e)}")
        #     return {
        #         "original_structure": None,
        #         "modified_structure": None,
        #         "edit_distance": None
        #     }


    def parse_formula(self, formula_str):
       
        # import pdb; pdb.set_trace()
        # try:
        if True:
            if isinstance(formula_str, sp.Basic):
                return formula_str
                
            # 预处理三角函数
            trig_funcs = {
                'sin': sp.sin,
                'cos': sp.cos,
                'tan': sp.tan,
                'cot': sp.cot
            }
            
            # 创建局部命名空间
            local_dict = {
                **trig_funcs,
                'pi': sp.pi,
                'E': sp.E,
                'I': sp.I
            }
            
            # 添加基本变量，使用实数假设
            variables = ['x', 'y', 'z', 'a', 'b', 'c', 'n', 'k', 'm', 
                        'alpha', 'beta', 'gamma', 'theta']
            for var in variables:
                local_dict[var] = sp.Symbol(var, real=True, finite=True)
            
            # 确保 formula_str 是字符串类型
            if not isinstance(formula_str, str):
                formula_str = str(formula_str)
            
            # 预处理幂运算
            formula_str = formula_str.replace('^', '**')
            
            # 先尝试简单解析
            #try:
            expr = sp.sympify(formula_str, locals=local_dict)
            #    print(1)
            #except:
                # 如果失败，尝试更安全的解析方式
            #    try:
            #        expr = sp.parse_expr(formula_str, local_dict=local_dict, transformations='all')
            #        print(2)
            #    except Exception as e:
            #        import pdb; pdb.set_trace()
            #        print(3)
            #print(4)
            return expr
            
        # except Exception as e:
        #     print(f"解析公式时出错: {str(e)}")
        #     return None


    def record_structure(self, expr):
        #结构记录函数
        # try:
            structure = {}
            
            def process_term(term, current_dict, index):
                if isinstance(term, (sp.Add, sp.Mul, sp.sin, sp.cos, sp.tan, sp.cot)):
                    current_dict[str(index)] = {
                        'type': term.__class__.__name__,
                        'content': str(term),
                        'terms': {}
                    }
                    if hasattr(term, 'args'):
                        for i, subterm in enumerate(term.args):
                            process_term(subterm, current_dict[str(index)]['terms'], i)
                else:
                    current_dict[str(index)] = {
                        'type': 'Basic',
                        'content': str(term)
                    }
                
            if isinstance(expr, (sp.Add, sp.Mul, sp.sin, sp.cos, sp.tan, sp.cot)):
                for i, term in enumerate(expr.args):
                    process_term(term, structure, i)
            else:
                process_term(expr, structure, 0)
                
            return structure
        # except Exception as e:
        #     print(f"记录结构时出错: {str(e)}")
        #     return {}


    def compute_edit_distance(self, struct1, struct2):
        #计算两个结构之间的编辑距离
        def get_structure_sequence(struct):
            #结构转换为了序列
            sequence = []
            
            def traverse(d):
                if isinstance(d, dict):
                    for key in sorted(d.keys()):  # 确保顺序一致
                        if isinstance(d[key], dict) and 'type' in d[key]:
                            sequence.append(f"{d[key]['type']}_{d[key]['content']}")
                            if 'terms' in d[key]:
                                traverse(d[key]['terms'])
                        elif isinstance(d[key], dict):
                            traverse(d[key])
            
            traverse(struct)
            return sequence
            
        # 获取两个结构的序列表示
        seq1 = get_structure_sequence(struct1)
        seq2 = get_structure_sequence(struct2)
        
        # 算编辑距离
        return 0#fuzz.ratio(''.join(seq1), ''.join(seq2))

    def execute_functions(self, user_formula, times=None):
        print(f"\n=== 开始执行变换 ===")
        print(f"输入公式: {user_formula}")
        print(f"计划执行次数: {times}")
        
        if times is None:
            times = random.randint(1, 10)
        
        results = []
        score = 0
        try:
            # 确保初始表达式是 SymPy 对象
            expr, variables = self.parse_user_formula(user_formula)
            print(f"转换后的字符串: '{expr}'")
            if expr is None:
                return results
            
            current_expr = expr
            result = {
                "formula": {"left": None, "right": None},
                "tricks": [],
                "complexity": {
                    "edit_distance": None,
                    "score": 0
                },
            }
            
            # 执行指定次数的变换
            for _ in range(times):
            
                # 确保 current_expr 是 SymPy 对象
                if not isinstance(current_expr, (sp.Eq, sp.Expr)):
                    continue
                
                left_part = current_expr.lhs if isinstance(current_expr, sp.Eq) else current_expr
                right_part = current_expr.rhs if isinstance(current_expr, sp.Eq) else None
                
                result["formula"]["left"] = str(left_part)
                result["formula"]["right"] = str(right_part) if right_part is not None else None
                
                # 随机选择一个操作
                operation = random.choice(self.operations_list)
                transformed = None
                
                # 执行选中的操作
                if operation == 1:
                    transformed = self.replace_with_number(current_expr)
                    if transformed is not None:
                        score += 1
                elif operation == 2:
                    transformed = self.replace_with_variable(current_expr, variables)
                    if transformed is not None:
                        score += 1
                elif operation == 3:
                    transformed, substitutions = self.replace_with_formula(current_expr, variables)
                    if transformed != current_expr:  # 检查是否真的发生了变化
                        # 计算替换分数
                        def formula_replace_score_calculate(orig_formula, formula):
                            try:
                                if isinstance(orig_formula, str):
                                    orig_formula = self.parse_user_formula(orig_formula)[0]
                                if isinstance(formula, str):
                                    formula = self.parse_user_formula(formula)[0]    
                                orig_vars = list(orig_formula.free_symbols)
                                formula_vars = list(formula.free_symbols)
                                overlap_vars = [var for var in orig_vars if var in formula_vars]
                                new_vars = [var for var in formula_vars if var not in orig_vars]
                                return len(overlap_vars) - len(orig_vars) + len(new_vars)
                            except Exception as e:
                                print(f"计算替换分数时出错: {str(e)}")
                                return 0
                        
                        score += formula_replace_score_calculate(current_expr, transformed)
                elif operation == 4:
                    transformed = self.multiply_with_num(current_expr)
                    score += 1
                elif operation == 5:
                    transformed = self.num_replace_with_num(current_expr)
                elif operation == 6:
                    transformed = self.swap_mul_terms(current_expr)
                    score += 1
                elif operation == 7:
                    transformed, _ = self.swap_terms(current_expr, variables)
                    score += 1
                elif operation == 8:
                    transformed = self.add_elements(current_expr)
                    score += 1
                
                if transformed is not None:
                    result['tricks'].append({
                        "operation": operation,
                        "formula_after": str(transformed)
                    })
                    
                    result['complexity']['score'] = score
                    current_expr = transformed  # 保持为 SymPy 对象
     
            results.append(result)
        
        except Exception as e:
            print(f"执行函数时出错: {str(e)}")
        
        return results